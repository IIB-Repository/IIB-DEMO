import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.jpos.iso.ISOException;
import org.jpos.iso.ISOField;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOPackager;
import org.jpos.iso.channel.PostChannel;
import org.jpos.iso.packager.ISOFinacleBWYPackager;

import postilion.esocketweb.AccountsTransfer;
import postilion.esocketweb.Amount;
import postilion.esocketweb.ESocketWeb;
import postilion.esocketweb.Financial;
import postilion.esocketweb.Identification;
import postilion.esocketweb.LinkedAccountsInquiry;
import postilion.esocketweb.Routing;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import com.ibm.security.krb5.internal.ccache.e;
import com.ibm.xtq.ast.nodes.FLWORExpr;
import com.ibm.xylem.instructions.SubstreamAfterInstruction;

public class VeriCash_process_request_JavaCompute extends MbJavaComputeNode {

	static String Rescode = new String();

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbMessageAssembly outAssembly = null;

		String returnValue = new String();
		PostChannel channel = null;
		String txnAmount = new String();
		String decPointStr = new String();
		String txnAmtStr = new String();
		String txnDate = new String();
		String valueDate = new String();
		String debitCurrency = new String();
		String isoFLD24 = new String();
		String txnCurrency = new String();
		String isoMTI = new String();
		String bankID = new String();
		String solID = new String();
		String fld102solID = new String();
		String fld102bankid = new String();
		String fld102drAcctNO = new String();
		String fld103crAcctNO = new String();
		String completeFld102 = new String();
		String completeFld103 = new String();
		String drAcctNO = new String();
		String crAcctNO = new String();
		String uid = new String();
		String uidate = new String();
		String errReason = "";
		String Actioncode = "";
		String stan = "";
		String f48 = "";
		String f125 = "";
		String status = "";
		String f56 = "";
		String f62 = "";
		String isoFLD125 = new String();
		String terminalloc = new String();
		String reservfld = new String();
		String tranDateTime = "";
		Date d = new Date();
		
	/*Added as per request on 06-Dec-2017*/
		String subcode = new String();
	/*----------------------------------*/
		int uidLength;

		String inpprcncode = "";
		try {
			MbElement InMSGENV = inAssembly.getGlobalEnvironment()
					.getRootElement();
			MbElement inpprcncodeMB = InMSGENV
					.getFirstElementByPath("/Variables/ProcessingCode");
			inpprcncode = (String) inpprcncodeMB.getValueAsString();
			// outAssembly=new
			// MbMessageAssembly(inAssembly,inAssembly.getMessage());
			MbMessage inMessage = inAssembly.getMessage();
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);

			if (inpprcncode.equalsIgnoreCase("84")) {
				PefromDebitCardValidation(inAssembly, outAssembly);
			} else {

				// PerformVeriCashOperations(inAssembly, outAssembly);

				MbElement env = inAssembly.getGlobalEnvironment()
						.getRootElement();
				inpprcncodeMB = env
						.getFirstElementByPath("/Variables/ProcessingCode");
				inpprcncode = (String) inpprcncodeMB.getValueAsString();

				if (inpprcncode.equalsIgnoreCase("51")) {

					isoMTI = "1420";
					isoFLD24 = "400";

				} else {
					isoMTI = (String) getUserDefinedAttribute("ISOMTI");
					isoFLD24 = (String) getUserDefinedAttribute("ISOFLD24");
				}

				String isoFLD3 = (String) getUserDefinedAttribute("ISOFLD3");
				String isoFLD32 = (String) getUserDefinedAttribute("ISOFLD32");
				String isoFLD123 = (String) getUserDefinedAttribute("ISOFLD123");
				String isoFLD124 = (String) getUserDefinedAttribute("ISOFLD124");
				String isoFLD41 = (String) getUserDefinedAttribute("ISOFLD41");

				BigDecimal txnAmt = null;

				outMessage = new MbMessage();
				try {

					MbElement inputRoot = inAssembly.getMessage()
							.getRootElement();
					// ISOFinaclePackager finaclePackager= new
					// ISOFinaclePackager();
					ISOPackager finaclePackager = new ISOFinacleBWYPackager();
					ISOMsg m = new ISOMsg();
					m.setPackager(finaclePackager);
					m.setMTI(isoMTI);
					// headers
					MbElement hostNameMB = env
							.getFirstElementByPath("/Variables/tcpHostname");
					String hostName = (String) hostNameMB.getValueAsString();
					MbElement tcpPortMB = env
							.getFirstElementByPath("/Variables/tcpPort");
					String tcpPortStr = tcpPortMB.getValueAsString();
					Integer i = Integer.parseInt(tcpPortStr);
					int tcpport = (int) i;

					if (inpprcncode.equalsIgnoreCase("100")) {

					}

					if (inpprcncode.equalsIgnoreCase("100")) {

						String chqstrtno = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/ChqNumber");
						int chqstrtnoLength;
						// If amount length is less than 16 pad with 0
						// changes are from length 8 to 16
						chqstrtnoLength = chqstrtno.length();
						if ((chqstrtnoLength > 0) && (chqstrtnoLength < 16)) {
							chqstrtnoLength = 16 - chqstrtnoLength;
							while (chqstrtnoLength > 0) {
								chqstrtno = "0".concat(chqstrtno);
								chqstrtnoLength = chqstrtnoLength - 1;
							}// End While
						}

						f62 = chqstrtno + "001";

						txnCurrency = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/TRAN_CRNCY_CODE");
						debitCurrency = txnCurrency;
						MbMessage f62_100 = outAssembly.getGlobalEnvironment();
						f62_100.getRootElement().createElementAsFirstChild(
								MbElement.TYPE_NAME_VALUE,
								"field62_ChequeStatus", chqstrtno);

					}

					if (inpprcncode.equalsIgnoreCase("95")) {
						// MbMessage envr=outAssembly.getGlobalEnvironment();
						// envr.getRootElement().createElementAsFirstChild(MbElement.TYPE_NAME_VALUE,"Variables",
						// "95");
						// String f46 = getValueByValidate(inputRoot,
						// "/XMLNSC/C24TRANREQ/fees");

						String chqstrtno = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/CHEQUE_REFERENCE_NUMBER");
						MbMessage envrs = outAssembly.getGlobalEnvironment();
						envrs.getRootElement().createElementAsFirstChild(
								MbElement.TYPE_NAME_VALUE,
								"ChequeNumber_before", chqstrtno);

						// MbElement env =outAssembly.get

						int chqstrtnoLength;
						// If amount length is less than 16 pad with 0
						// changes are from length 8 to 16
						chqstrtnoLength = chqstrtno.length();
						if ((chqstrtnoLength > 0) && (chqstrtnoLength < 16)) {
							chqstrtnoLength = 16 - chqstrtnoLength;
							while (chqstrtnoLength > 0) {
								chqstrtno = "0".concat(chqstrtno);
								chqstrtnoLength = chqstrtnoLength - 1;
							}// End While
						}

						MbMessage envr = outAssembly.getGlobalEnvironment();
						envr.getRootElement().createElementAsFirstChild(
								MbElement.TYPE_NAME_VALUE,
								"ChequeNumber_after", chqstrtno);

						// --MbElement
						// chqn=outAssembly.getGlobalEnvironment().getRootEle
						// MbElement

						/*
						 * String noofleave = getValueByValidate(inputRoot,
						 * "/XMLNSC/C24TRANREQ/no_of_leaves");
						 * 
						 * 
						 * int noofleaveLength; //If amount length is less than
						 * 16 pad with 0 noofleaveLength = noofleave.length();
						 * if((noofleaveLength > 0 )&&(noofleaveLength<3)){
						 * noofleaveLength = 3-noofleaveLength;
						 * while(chqstrtnoLength>0){ noofleave =
						 * "0".concat(chqstrtno); noofleaveLength =
						 * noofleaveLength-1; }//End While }
						 */

						String stopReason = "   "
								.concat((String) getUserDefinedAttribute("STOPREASON"));
						f62 = chqstrtno + "001" + stopReason;
						txnCurrency = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/TRAN_CRNCY_CODE");
						debitCurrency = txnCurrency;
						MbMessage f62ref = outAssembly.getGlobalEnvironment();
						f62ref.getRootElement().createElementAsFirstChild(
								MbElement.TYPE_NAME_VALUE, "Field62_Cheque",
								f62);

					}
					if (inpprcncode.equalsIgnoreCase("51")) {
						String Origstan = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/ORIGINAL_STAN");

						int OrigstanLength;
						// If stan length is less than 12 pad with 0
						OrigstanLength = Origstan.length();
						if ((OrigstanLength > 0) && (OrigstanLength < 12)) {
							OrigstanLength = 12 - OrigstanLength;
							while (OrigstanLength > 0) {
								Origstan = "0".concat(Origstan);
								OrigstanLength = OrigstanLength - 1;
							}// End While
						}

						String Origdtetime = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/ORIGINAL_DATE_TIME");
						/*
						 * int OrigdtetimeLength; //If amount length is less
						 * than 16 pad with 0 OrigdtetimeLength =
						 * Origstan.length(); if((OrigdtetimeLength > 0
						 * )&&(OrigdtetimeLength<14)){ OrigdtetimeLength =
						 * 14-OrigdtetimeLength; while(OrigdtetimeLength>0){
						 * Origdtetime = "0".concat(Origdtetime);
						 * OrigdtetimeLength = OrigdtetimeLength-1; }//End While
						 * }
						 */

						String AcqInst = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/ORIG_INST_CODE");

						int AcqInstLength;
						// If amount length is less than 16 pad with 0
						AcqInstLength = AcqInst.length();
						if ((AcqInstLength > 0) && (AcqInstLength < 11)) {
							AcqInstLength = 11 - AcqInstLength;
							while (AcqInstLength > 0) {
								AcqInst = "0".concat(AcqInst);
								AcqInstLength = AcqInstLength - 1;
							}// End While
						}

						f56 = "1200" + Origstan + Origdtetime + "11" + AcqInst;
					}

					if (inpprcncode.equalsIgnoreCase("70")
							|| inpprcncode.equalsIgnoreCase("50")
							|| inpprcncode.equalsIgnoreCase("51")) {
						txnAmount = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/TRAN_AMT");

						decPointStr = env.getFirstElementByPath(
								"/Variables/Txn/decPoint").getValueAsString();
						int decPoint = Integer.parseInt(decPointStr.substring(
								0, 1));
						txnAmt = new BigDecimal(txnAmount);
						double base = 10;
						double exponent = decPoint;
						// Removing decimal point
						
						
						/*----------------------------------------------------------------------*/
						/* 	txnAmt = txnAmt.multiply(new BigDecimal(Math.pow(base,
								exponent)));
						txnAmt = txnAmt.setScale(0, RoundingMode.FLOOR);			*/
						
						
						/*----------Changed code as per request on 06-Dec-2017---------*/
						
						/* If the subcode is CG the txn amount will take same as input, for other countries it will multiply by 100 */
						subcode = getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/COUNTRY_CODE" );
						if (subcode.equals("CG")) {
							txnAmt = txnAmt.setScale(0, RoundingMode.FLOOR);
						} else {
							txnAmt = txnAmt.multiply(new BigDecimal(Math.pow(base, exponent)));
							txnAmt = txnAmt.setScale(0, RoundingMode.FLOOR);
						}
						/*------------------------------------------------------------------------*/

						
						
						// Throw exception if length is greater than 16
						if (txnAmt.toString().length() > 16) {
							throw new MbUserException(
									this,
									"evaluate()",
									"",
									"",
									"ESB internal Exception Txn Amt is Exceeded limit",
									null);
						}
						String amount = txnAmt.toString();
						int amountLength;
						// If amount length is less than 16 pad with 0
						amountLength = amount.length();
						if ((amountLength > 0) && (amountLength < 16)) {
							amountLength = 16 - amountLength;
							while (amountLength > 0) {
								amount = "0".concat(amount);
								amountLength = amountLength - 1;
							}// End While
						}// End IF
						txnAmtStr = amount;
					}
					uidate = new SimpleDateFormat("mmss").format(d);
					SecureRandom prng = SecureRandom.getInstance("SHA1PRNG");
					uid = new Integer(prng.nextInt()).toString();
					// Generate unique id
					if (uid.length() >= 8) {
						uid = uid.substring(uid.length() - 8, uid.length());
					} else {
						uidLength = 8 - uid.length();
						while (uidLength > 0) {
							uid = uid.concat("1");
							uidLength = uidLength - 1;
						}// End while uidLength
					}// End else
					uid = uidate + uid;
					uid = uid.replace("-", "1");

					txnDate = env.getFirstElementByPath("/Variables/CurrDte")
							.getValueAsString();

					txnDate = txnDate.replace("-", "");
					txnDate = txnDate.replace(":", "");
					txnDate = txnDate.replace("T", "");
					// txnDate = txnDate.concat("000000");
					// valueDate =
					// inputRoot.getFirstElementByPath("/XMLNSC/MSGDETAIL/VALUEDATE").getValueAsString();
					valueDate = env.getFirstElementByPath("/Variables/ValDte")
							.getValueAsString();

					valueDate = valueDate.replace("-", "");
					valueDate = valueDate.replace(":", "");
					valueDate = valueDate.replace("T", "");

					// txnCurrency =
					// getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/TXNCCY");
					// txnCurrency =
					// getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/TRAN_CRNCY_CODE");

					bankID = env.getFirstElementByPath("/Variables/Iso/bankID")
							.getValueAsString();
					fld102bankid = String.format("%1$" + (-11) + "s", bankID);
					solID = env.getFirstElementByPath("/Variables/Iso/solID")
							.getValueAsString();
					fld102solID = String.format("%1$" + (-8) + "s", solID);

					if (inpprcncode.equalsIgnoreCase("100")) {
						drAcctNO = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/AccountNo");
					} else {
						drAcctNO = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/DR_ACCT_NUM");
					}
					fld102drAcctNO = String.format("%1$" + (-19) + "s",
							drAcctNO);
					completeFld102 = fld102bankid + fld102solID
							+ fld102drAcctNO;

					if (inpprcncode.equalsIgnoreCase("70")) {
						crAcctNO = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/CR_ACCT_NUM");
						fld103crAcctNO = String.format("%1$" + (-19) + "s",
								crAcctNO);
						completeFld103 = fld102bankid + fld102solID
								+ fld103crAcctNO;
					}
					if (inpprcncode.equalsIgnoreCase("51")) {
						String spce = "  ";
						crAcctNO = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/CR_ACCT_NUM");
						fld103crAcctNO = String.format("%1$" + (-19) + "s",
								crAcctNO);
						completeFld103 = spce + fld102bankid + fld102solID
								+ fld103crAcctNO;

						txnCurrency = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/TRAN_CRNCY_CODE");
						debitCurrency = txnCurrency;

						/*
						 * added RESERVE_FLD_1 to field 125 & TERMINAL_NAME_LOC
						 * to field suggested by sunday on 08-sept-2015
						 */
						isoFLD125 = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/RESERVE_FLD_1");
						reservfld = inputRoot.getFirstElementByPath(
								"/XMLNSC/C24TRANREQ/TERMINAL_NAME_LOC")
								.getValueAsString();

						if (reservfld == null)

						{
							reservfld = " ";
						} else {
							reservfld = getValueByValidate(inputRoot,
									"/XMLNSC/C24TRANREQ/TERMINAL_NAME_LOC");

						}
					}

					if (inpprcncode.equalsIgnoreCase("50")) {

						stan = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/STAN");
						if (stan == null) {
							stan = "";
						}
						int stanLength = stan.length();
						// If stan length is less than 12 pad with 0

						if ((stanLength > 0) && (stanLength < 12)) {
							stanLength = 12 - stanLength;
							while (stanLength > 0) {
								stan = "0".concat(stan);
								stanLength = stanLength - 1;
							}// End While
						}

						tranDateTime = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/TRAN_DATE_TIME");
						m.set(new ISOField(12, tranDateTime));

						crAcctNO = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/CR_ACCT_NUM");
						String spce = "  ";
						fld103crAcctNO = String.format("%1$" + (-19) + "s",
								crAcctNO);
						completeFld103 = spce + fld102bankid + fld102solID
								+ fld103crAcctNO;
						txnCurrency = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/TRAN_CRNCY_CODE");
						debitCurrency = txnCurrency;
						/*
						 * added RESERVE_FLD_1 to field 125 & TERMINAL_NAME_LOC
						 * to field 43 suggested by sunday on 08-sept-2015
						 */
						isoFLD125 = getValueByValidate(inputRoot,
								"/XMLNSC/C24TRANREQ/RESERVED_FLD_1");
						reservfld = inputRoot.getFirstElementByPath(
								"/XMLNSC/C24TRANREQ/TERMINAL_NAME_LOC")
								.getValueAsString();

						if (reservfld == null)

						{
							reservfld = " ";
						} else {
							reservfld = getValueByValidate(inputRoot,
									"/XMLNSC/C24TRANREQ/TERMINAL_NAME_LOC");

						}

					}

					if (inpprcncode.equalsIgnoreCase("31")) {
						isoFLD3 = "310000";
					}
					if (inpprcncode.equalsIgnoreCase("100")) {
						isoFLD3 = "940000";
					}
					if (inpprcncode.equalsIgnoreCase("95")) {
						isoFLD3 = "950000";
					}
					if (inpprcncode.equalsIgnoreCase("38")) {
						isoFLD3 = "380000";
					}
					if (inpprcncode.equalsIgnoreCase("82")) {
						isoFLD3 = "820000";

					}

					m.set(new ISOField(2, "VERICASH"));
					m.set(new ISOField(3, isoFLD3));
					if (inpprcncode.equalsIgnoreCase("70")
							|| inpprcncode.equalsIgnoreCase("50")
							|| inpprcncode.equalsIgnoreCase("51")) {
						if (txnAmtStr != null) {
							m.set(new ISOField(4, txnAmtStr));
						}
					} else {
						m.set(new ISOField(4, "0000000000000000"));
					}

					if (inpprcncode.equalsIgnoreCase("50")) {
						m.set(new ISOField(11, stan));
					} else {
						m.set(new ISOField(11, uid));
					}

					if (inpprcncode.equalsIgnoreCase("50"))

					{

						m.set(new ISOField(12, tranDateTime));
					} else {
						m.set(new ISOField(12, txnDate));
					}

					if (valueDate != null) {
						m.set(new ISOField(17, valueDate));
					}
					m.set(new ISOField(24, isoFLD24));
					m.set(new ISOField(32, isoFLD32));

					if (inpprcncode.equalsIgnoreCase("50")) {
						/*
						 * adding field 41 value suggested by sunday on
						 * 08-sep-2015
						 */
						m.set(new ISOField(41, isoFLD41));
						if (reservfld.length() > 50) {
							m.set(new ISOField(43, reservfld.substring(0, 50)));
						} else {
							m.set(new ISOField(43, reservfld));
						}
					}
					/*
					 * added TERMINAL_NAME_LOC to field 43 suggested by sunday
					 * on 08-sept-2015
					 */

					if (inpprcncode.equalsIgnoreCase("51")) {
						/*
						 * adding field 41 value suggested by sunday on
						 * 08-sep-2015
						 */
						m.set(new ISOField(41, isoFLD41));
						if (reservfld.length() > 50) {
							m.set(new ISOField(43, reservfld.substring(0, 50)));
						} else {
							m.set(new ISOField(43, reservfld));
						}
					}

					if (inpprcncode.equalsIgnoreCase("70")
							|| inpprcncode.equalsIgnoreCase("50")
							|| inpprcncode.equalsIgnoreCase("100")
							|| inpprcncode.equalsIgnoreCase("51")
							|| inpprcncode.equalsIgnoreCase("95")) {
						if (debitCurrency != null) {
							m.set(new ISOField(49, debitCurrency));
						}

						if (txnCurrency != null) {
							m.set(new ISOField(50, txnCurrency));
						}
					}
					if (inpprcncode.equalsIgnoreCase("51")) {
						if (f56 != null) {
							m.set(new ISOField(56, f56));
						}
					}

					/*
					 * added TERMINAL_NAME_LOC to field 63 suggested by sunday
					 * on 08-sept-2015
					 */

					if (inpprcncode.equalsIgnoreCase("50")
							|| inpprcncode.equalsIgnoreCase("51")) {
						// if (reservfld==null)reservfld="";

						// changes applied by sunday 09-Sep-2015
						if (reservfld.length() > 28) {
							m.set(new ISOField(63, reservfld.substring(0, 28)));
						} else {
							m.set(new ISOField(63, reservfld));
						}

					}

					if (inpprcncode.equalsIgnoreCase("95")
							|| inpprcncode.equalsIgnoreCase("100")) {
						if (f62 != null) {
							m.set(new ISOField(62, f62));
						}

					}
					if (completeFld102 != null) {
						m.set(new ISOField(102, completeFld102));
					}

					if (inpprcncode.equalsIgnoreCase("50")
							|| inpprcncode.equalsIgnoreCase("51")) {
						if (completeFld103 != null) {
							m.set(new ISOField(103, completeFld103));
							// if (completeFld103 != null) {
						}
					}
					m.set(new ISOField(123, isoFLD123));
					m.set(new ISOField(124, isoFLD124));
					if (inpprcncode.equalsIgnoreCase("50")
							|| inpprcncode.equalsIgnoreCase("51")) {
						/* changes applied on 09 SEP 2015 */
						if (isoFLD125 == null)
							isoFLD125 = "";

						if (isoFLD125.length() > 50) {
							isoFLD125 = isoFLD125.substring(0, 50);
						}

						m.set(new ISOField(125, isoFLD125));

					}

					channel = new PostChannel(hostName, tcpport,
							finaclePackager);
					MbElement envFinRetry = env.createElementAsLastChild(
							MbXMLNSC.FOLDER, "FinacleRetry", null);

					ISOMsg resp = null;
					
					try {
						
						resp = finacleConnect(channel, m, envFinRetry);
						// we need to do same here
						if (resp!=null) {
							errReason = resp.getString(127);
							Actioncode = resp.getString(39);
						}else{
							errReason = " ";
							Actioncode = "907";	//  error connecting to finacle
							// this is fine, right?
							//yes
							//but action code will it go with response?
							// it depends on how u hav handled it; to u prefer sending thru alternate terminalD
							//for exc i send thru alternate,
							 //
							getOutputTerminal("alternate").propagate(outAssembly); // this should be fine right? 
					//for java
							
						}
					} catch (SocketTimeoutException timeoutExc) {
						timeoutExc.printStackTrace();
						errReason="Error Connecting to Connect 24 Service";
						getOutputTerminal("alternate").propagate(outAssembly);
                        //return;
					} catch (Exception e) {
						// TODO Auto-generated catch block
						errReason="Error Connecting to Connect 24 Service";
						getOutputTerminal("alternate").propagate(outAssembly);
						//return;
					}

                    
					if (Actioncode.equalsIgnoreCase("000")) {
						status = "SUCCESS";
						/*
						 * f48 = resp.getString(48); // f48len = f48.length();
						 * f125 =resp.getString(125); //f125len = f125.length();
						 */
					} else {
						status = "FAILED";
					}
					stan = resp.getString(11);
					f48 = resp.getString(48);
					// int f48len = f48.length();
					f125 = resp.getString(125);
					if (f125 != null) {
						f125 = f125.replace("&amp;", " ");
						f125 = f125.trim();
					}
					// MbMessage f125ref = outAssembly.getGlobalEnvironment();
					// f125ref.getRootElement().createElementAsFirstChild(MbElement.TYPE_NAME_VALUE,
					// "field125Val", f125);

					// f125len = f125.length();
					inMessage = inAssembly.getMessage();
					outAssembly = new MbMessageAssembly(inAssembly, outMessage);
					// copy headers from the input message
					copyMessageHeaders(inMessage, outMessage);
					// Create the XMLNSC Parser element
					MbElement outParser = outMessage.getRootElement()
							.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
					MbElement outBody = outParser.createElementAsFirstChild(
							MbXMLNSC.FOLDER, "MSG", null);

					MbElement outBodyList = outBody.createElementAsLastChild(
							MbXMLNSC.FOLDER, "C24TRANRES", null);
					outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
							"ACTION_CODE", Actioncode);
					outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
							"STAN", stan);
					outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
							"TRAN_DATE_TIME", resp.getString(12));
					outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
							"FIELD48", f48);
					// outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
					// "F48LEN",
					// f48len);
					outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
							"FIELD125", f125);
					// outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
					// "F125LEN",
					// f125len);
					outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
							"STATUS", status);
					outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
							"ERRCODE", Actioncode);

					// Propagate the message to out terminal
					getOutputTerminal("out").propagate(outAssembly);


				}// End catch socket time out exception
				catch (MbException e) {
					e.printStackTrace();
					// appled change on 290915
					getOutputTerminal("alternate").propagate(outAssembly);
				} catch (Exception exp) {
					// exp.printStackTrace()Actioncode;
					exp.printStackTrace();
					// appled change on 290915
					getOutputTerminal("alternate").propagate(outAssembly);
				}
				// Disconnecting finacle system connection
				finally {
					try {
						if (channel != null) {
							channel.disconnect();
							//channel.c
						}
						if (outMessage != null) {
							outMessage.clearMessage();
						}
					} catch (IOException e) {
						e.printStackTrace();
						// appled change on 290915
						getOutputTerminal("alternate").propagate(outAssembly);
					}
				}// End finally disconnecting finacle connection
				channel = null;
			}

			// ----------------------------------------------------------

			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			e.printStackTrace();
			getOutputTerminal("alternate").propagate(outAssembly);
		} catch (RuntimeException e) {

			e.printStackTrace();
			getOutputTerminal("alternate").propagate(outAssembly);
		} catch (Exception e) {

			e.printStackTrace();
			getOutputTerminal("alternate").propagate(outAssembly);
		}

	}

	public void PefromDebitCardValidation(MbMessageAssembly VerRequestMsg,
			MbMessageAssembly outAssembly) throws MbException {
		// Connecting to the Card Management server .
		// final String ZPK="027FAAD07C7AF55EE079C962607EE2FE";
		// final int KEYSIZE=168;
		String ZPK = getUserDefinedAttribute("ZPK").toString();
		String flag = "";
		int KEYSIZE = Integer.parseInt(getUserDefinedAttribute("KEYSIZE")
				.toString());
		MbMessage outMessage = new MbMessage();
		ESocketWeb esocketweb = null;
		try {
			String CardNUM = new String();
			String Year = new String();
			String Month = new String();
			String Amount = new String();
			String Currency = new String();
			String pin = new String();

			String AcquiringInstitution = new String();

			MbElement InMSG = VerRequestMsg.getMessage().getRootElement();
			MbElement env = VerRequestMsg.getGlobalEnvironment()
					.getRootElement();// headers
			// pin =
			// InMSG.getFirstElementByPath("/XMLNSC/C24TRANREQ/CARD_PIN").getValueAsString();
			pin = InMSG.getFirstElementByPath("XMLNSC/C24TRANREQ/CARD_PIN")
					.getValueAsString();
			MbElement yearMB = env.getFirstElementByPath("/var/cbms/year");
			MbElement monthMB = env.getFirstElementByPath("/var/cbms/month");
			// CardNUM =
			// InMSG.getFirstElementByPath("/XMLNSC/C24TRANREQ/CARD_NUMBER").getValueAsString();
			CardNUM = InMSG.getFirstElementByPath(
					"/XMLNSC/C24TRANREQ/CARD_NUMBER").getValueAsString();
			Year = (String) yearMB.getValueAsString();
			Month = (String) monthMB.getValueAsString();
			AcquiringInstitution = (String) getUserDefinedAttribute("ACQINST");

			esocketweb = new ESocketWeb();
			esocketweb.initialize("/var/UBA/VeriCash/ubaaccountesocket.txt"); // PENDING
																				// To
																				// be
																				// globally
																				// initialize
			try {
				esocketweb.connect();
			} catch (RuntimeException e1) {
				flag = "False";
			} catch (Throwable e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				flag = "False";
			}

			if (!esocketweb.isConnected()) {
				System.out.println("Connecting to e-Socket Server Failed");
				flag = "False";
				// here unconnected to server i out from alternate terminal, i
				// understand,. I just want to handle any other form of
				// exceptions

			} else {
				flag = "True";
				System.out.println("Connected to E-Socket Server Successfully");
			}

			// Can i change it?
			// yes pls

			// ok
			// Linked Account Inquiry inquiry
			// i declared as string nly ok
			if ("True".equalsIgnoreCase(flag)) {

				esocketweb.stopTracing();
				LinkedAccountsInquiry linkAcctEnqry = esocketweb
						.newLinkedAccountsInquiry();

				// identification info
				Identification identification = linkAcctEnqry
						.newIdentification();
				postilion.esocketweb.Card card = identification.newCard();
				card.setCardNumber(CardNUM);
				card.setPinData(PinBlockEncryptionUtil.encryptPinBlock(CardNUM,
						pin, ZPK, KEYSIZE));
				// card.setPinData(PinBlockEncryptionUtil.encryptPinBlock(CardNUM,
				// "1111", UBALinkedAccountInquiry.ZPK,
				// UBALinkedAccountInquiry.KEYSIZE));
				postilion.esocketweb.DateTime expiryDate = card.newExpiryDate();
				expiryDate.setYear(Year);
				expiryDate.setMonth(Month);

				Routing routing = linkAcctEnqry.newRouting();
				routing.setAcquiringInstitution(AcquiringInstitution);

				LinkedAccountsInquiry linkAcctEnqryResp;

				try {
					String resp = "";
					String status = "";
					linkAcctEnqryResp = (LinkedAccountsInquiry) esocketweb
							.send(linkAcctEnqry);

					outAssembly = new MbMessageAssembly(VerRequestMsg,
							outMessage);
					// copy headers from the input message
					MbMessage inMessage = VerRequestMsg.getMessage();
					copyMessageHeaders(inMessage, outMessage);
					if (linkAcctEnqryResp.getResponse().getResponseCode()
							.equals("00")) {
						System.out
								.println("Linked Account Inquiry was successful");
						resp = "000";
						status = "SUCCESS";
						MbElement outParser = outMessage.getRootElement()
								.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
						MbElement outBody = outParser
								.createElementAsFirstChild(MbXMLNSC.FOLDER,
										"MSG", null);
						MbElement outBodyList = outBody
								.createElementAsLastChild(MbXMLNSC.FOLDER,
										"C24TRANRES", null);
						outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
								"RESPCODE", resp);
						outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
								"STATUS", status);

						java.util.Hashtable linkAcctList = linkAcctEnqryResp
								.getLinkedAccountsList().getFields();

						Object[] ls = linkAcctList.values().toArray();

						int x = 1;
						// for (LinkedAccount linkedAcct : ls)
						String[] acctType = new String[ls.length];
						String[] acctId = new String[ls.length];
						String[] acctCurrency = new String[ls.length];

						for (int k = 0; k < ls.length; k++) {
							postilion.esocketweb.Account acct = ((postilion.esocketweb.LinkedAccount) ls[k])
									.getAccount();
							acctType[k] = acct.getType();
							acctId[k] = acct.getId();
							acctCurrency[k] = acct.getCurrency();

							System.out.println("Acct Type = " + acctType[k]
									+ " Acct Id = " + acctId[k]
									+ " Acct Currency = " + acctCurrency[k]);
							// System.out.println(" Sending Transfer Instruction ... ");

							// building the Response
							MbElement inBodyList = outBodyList
									.createElementAsLastChild(MbXMLNSC.FOLDER,
											"ACCOUNTS", null);
							inBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
									"ACCOUNTID", acctId[k]);
							inBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
									"ACCOUNTTYPE", acctType[k]);
							inBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
									"ACCOUNTCCY", acctCurrency[k]);

						}
						getOutputTerminal("out").propagate(outAssembly);
					} else {
						resp = linkAcctEnqryResp.getResponse()
								.getResponseCode();
						status = "FAILURE";
						MbElement outParser = outMessage.getRootElement()
								.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
						MbElement outBody = outParser
								.createElementAsFirstChild(MbXMLNSC.FOLDER,
										"MSG", null);
						MbElement outBodyList = outBody
								.createElementAsLastChild(MbXMLNSC.FOLDER,
										"C24TRANRES", null);
						outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
								"RESPCODE", resp);
						outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
								"STATUS", status);

						getOutputTerminal("out").propagate(outAssembly);
					}

					//
				} catch (RuntimeException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

					String resp = "99";
					String status = "FAILURE";
					MbElement outParser = outMessage.getRootElement()
							.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
					MbElement outBody = outParser.createElementAsFirstChild(
							MbXMLNSC.FOLDER, "MSG", null);
					MbElement outBodyList = outBody.createElementAsLastChild(
							MbXMLNSC.FOLDER, "C24TRANRES", null);
					outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
							"RESPCODE", resp);
					outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
							"STATUS", status);
					getOutputTerminal("out").propagate(outAssembly);

				}
				// ok
				// is this OK by u?
				// this should handle all ur issues
				// thanks can we proceed our testigng

			} else {
				/*
				 * String resp = "99"; String status = "FAILURE"; MbElement
				 * outParser = outMessage.getRootElement()
				 * .createElementAsLastChild(MbXMLNSC.PARSER_NAME); MbElement
				 * outBody = outParser.createElementAsFirstChild(
				 * MbXMLNSC.FOLDER, "MSG", null); MbElement outBodyList =
				 * outBody.createElementAsLastChild( MbXMLNSC.FOLDER,
				 * "C24TRANRES", null);
				 * outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
				 * "RESPCODE", resp);
				 * outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,"STATUS",
				 * status); //should this go through alternate terminal? // this
				 * is for failures which responsecodes not '00', yes we send
				 * this through out. ok
				 */
				getOutputTerminal("alternate").propagate(outAssembly);

			}
		} catch (Exception exp) {
			// exp.printStackTrace();
			exp.printStackTrace();

			/*
			 * String resp = "99"; String status = "FAILURE"; MbElement
			 * outParser = outMessage.getRootElement()
			 * .createElementAsLastChild(MbXMLNSC.PARSER_NAME); MbElement
			 * outBody = outParser.createElementAsFirstChild( MbXMLNSC.FOLDER,
			 * "MSG", null); MbElement outBodyList =
			 * outBody.createElementAsLastChild( MbXMLNSC.FOLDER, "C24TRANRES",
			 * null); outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,
			 * "RESPCODE", resp);
			 * outBodyList.createElementAsLastChild(MbXMLNSC.FIELD,"STATUS",
			 * status); //should this go through alternate terminal? // this is
			 * for failures which responsecodes not '00', yes we send this
			 * through out. ok i think u rm good to go, u can test now
			 */getOutputTerminal("alternate").propagate(outAssembly);
			// r u ok with this? ok
			// for unconnected postilin servers i used flag variable sending
			// through aalternate terminal
			// that means,
			// this should be ok by u, right?
			// this is supposed to handle all forms of exceptions that may
			// happen during processing, r u ok?
			// here unconnected means it cant be exception , so
		}

		finally {

			if (esocketweb != null) {
				try {
					esocketweb.disconnect();
				} catch (RuntimeException e) {
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					esocketweb.close();
				} catch (RuntimeException e) {
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				esocketweb = null; // esocketweb.destroy();

			}

			// wait this line is wrong...
			// if ("False".equalsIgnoreCase(flag)){
			// getOutputTerminal("alternate").propagate(outAssembly);
			// //}

		}

	}

	// copy headers from the input message
	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage)
			throws MbException {
		MbElement outRoot = outMessage.getRootElement();
		// iterate though the headers starting with the first child of the root
		// element
		MbElement header = inMessage.getRootElement().getFirstChild();
		// stop before the last child
		while ((header != null) && (header.getNextSibling() != null)) {
			outRoot.addAsLastChild(header.copy());
			header = header.getNextSibling();
		}// End while
	}// End copy message headers

	public ISOMsg finacleConnect(PostChannel channel, ISOMsg m,
			MbElement envFinRetry) throws ISOException, IOException,
			InterruptedException, MbException {
		int c24waittime ;
		String returnValue = null;

		ISOMsg resp = null;
	//	while (true) {
			/**
			 * For Negitive Response hit the finacle server upto 3 times only.*
			 */
			//int noofretrials = (int) getUserDefinedAttribute("NOOFRETRIALS");
		//	if (finacleCount < noofretrials) {
				//what is happening here?
				//Why is it in a while (true) loop?
				// it is finacle retry 
				// we dont need to retry vericash transaction, please let's remove it
				//ok
				//
		        c24waittime=Integer.parseInt(getUserDefinedAttribute("C24_WAIT_TIME").toString());  
				try {
					channel.setTimeout(1000 * c24waittime);  
					channel.connect();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					returnValue="907";
				}
				
				try {
					channel.send(m);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// Receiving response from Finacle
				resp = channel.receive();
                // then this section is not necessary
				/*if (resp == null) {
					returnValue="911";
				}else{
				    returnValue = resp.getString(39);				
				}*/
				//this should solve all the issue on connect 24... U can test now
				//ok  , pls hold, u can now go ahead with ur test
				//1 sec
				//finacleCount = finacleCount + 1;
			//} else
				//break;
/*
			if ((returnValue.equalsIgnoreCase("904")
					|| returnValue.equalsIgnoreCase("906")
					|| returnValue.equalsIgnoreCase("911")
					|| returnValue.equalsIgnoreCase("907") || returnValue
						.equalsIgnoreCase("909"))
					&& finacleCount >= noofretrials) {
				break;
			}
			if (!returnValue.equalsIgnoreCase("904")
					&& !returnValue.equalsIgnoreCase("906")
					&& !returnValue.equalsIgnoreCase("911")
					&& !returnValue.equalsIgnoreCase("907")
					&& !returnValue.equalsIgnoreCase("909"))
				break;
			//Thread.sleep(30 * 1000);
			//MbElement iterationObj = envFinRetry.createElementAsLastChild(
			//		MbXMLNSC.FOLDER, "Iteration", null);
			//iterationObj.createElementAsLastChild(MbXMLNSC.FIELD,
			//		"returnValue", returnValue);
			//iterationObj.createElementAsLastChild(MbXMLNSC.FIELD,
				//	"ReturnCount", Integer.toString(finacleCount));

		}// End While*/

				// removed 
				//ok
		return resp;//this should return value right?
		//let me check

	}

	public String getValueByValidate(MbElement parentEle, String path)
			throws MbException {
		MbElement eleObj = null;
		String elementInStrg = null;

		eleObj = parentEle.getFirstElementByPath(path);
		if (eleObj != null) {
			elementInStrg = eleObj.getValueAsString();
			if (elementInStrg == null)
				throw new MbUserException(this, "getElementByPath()", "", "",
						path + " NULL", null);
		} else
			throw new MbUserException(this, "getElementByPath()", "", "", path
					+ " NULL", null);

		return elementInStrg;
	}

	// Validate Debt Card Expiry Date.

	public static String doTransfer(MbMessageAssembly VerRequestMsg,
			String[] acctId, String[] acctType, ESocketWeb esocketweb)
			throws MbException {
		try {
			String Rescode = new String();
			String CardNUM = new String();
			String Year = new String();
			String Month = new String();
			String Amount = new String();
			String Currency = new String();
			String AcquiringInstitution = new String();

			MbElement InMSG = VerRequestMsg.getMessage().getRootElement();
			CardNUM = InMSG.getFirstElementByPath(
					"/XMLNSC/C24TRANREQ/CARDNUMBER").toString();
			Year = InMSG.getFirstElementByPath("/XMLNSC/C24TRANREQ/YEAR")
					.toString();
			Month = InMSG.getFirstElementByPath("/XMLNSC/C24TRANREQ/MONTH")
					.toString();
			AcquiringInstitution = InMSG.getFirstElementByPath(
					"/XMLNSC/C24TRANREQ/ACQUIRINGINSTITUTION").toString();

			AccountsTransfer transfer = esocketweb.newAccountsTransfer();
			Identification identification = transfer.newIdentification();
			postilion.esocketweb.Card card = identification.newCard();
			card.setCardNumber(CardNUM);

			postilion.esocketweb.DateTime expiryDate = card.newExpiryDate();
			expiryDate.setYear(Year);
			expiryDate.setMonth(Month);
			System.out.println("22222222222");
			// financial info
			Financial financial = transfer.newFinancial();
			Amount amount = financial.newTransactionAmount();
			amount.setAmount(Amount);
			amount.setCurrency(Currency);
			financial.setTransactionAmount(amount);

			postilion.esocketweb.Account fromAccount = transfer
					.newFromAccount();
			fromAccount.setType(acctType[0]);
			fromAccount.setId(acctId[0]);
			fromAccount.setCurrency(Currency);

			postilion.esocketweb.Account toAccount = transfer.newToAccount();
			toAccount.setType(acctType[1]);
			toAccount.setId(acctId[1]);
			toAccount.setCurrency(Currency);
			System.out.println("33333333333");
			// Routing Info
			Routing routing = transfer.newRouting();
			routing.setAcquiringInstitution(AcquiringInstitution);
			System.out.println("444444444444");
			AccountsTransfer transferResponse = (AccountsTransfer) esocketweb
					.send(transfer);
			System.out.println("555555555555555");

			Rescode = transferResponse.getResponse().getResponseCode();
			if (transferResponse.getResponse().getResponseCode().equals("00")) {
				System.out.println("Account Transfer Was Successful ...");

			} else {
				System.out.println("Account Transfer FAILED!  ...");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return Rescode;

	}

}// End gcp finacle java compute class


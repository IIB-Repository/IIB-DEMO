import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.SocketTimeoutException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.jpos.iso.ISOException;
import org.jpos.iso.ISOField;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOPackager;
import org.jpos.iso.channel.PostChannel;
import org.jpos.iso.packager.ISOFinacleBWYPackager;
import org.jpos.iso.packager.ISOFinaclePackager;

import postesweb.core.util.DateTime;
import postesweb.core.xml.cardmanagementupdatedata.Card;
import postilion.esocketweb.AccountsTransfer;
import postilion.esocketweb.Amount;
import postilion.esocketweb.ESocketWeb;
import postilion.esocketweb.Financial;
import postilion.esocketweb.Identification;
import postilion.esocketweb.LinkedAccountsInquiry;
import postilion.esocketweb.Routing;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import com.vsi.xmlf.Account;


public class VeriCash_process_request_JavaCompute extends MbJavaComputeNode {
		
	static  String Rescode = new String();

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbMessageAssembly outAssembly = null;
		String inpprcncode = ""; 
		try {
			MbElement InMSGENV =inAssembly.getGlobalEnvironment().getRootElement();
			 MbElement inpprcncodeMB = InMSGENV.getFirstElementByPath("/Variables/ProcessingCode");
			 inpprcncode = (String)inpprcncodeMB.getValueAsString();
			if (inpprcncode.equalsIgnoreCase("84"))
			{
			PefromDebitCardValidation(inAssembly, outAssembly);
			} else
			{
			
			PerformVeriCashOperations(inAssembly, outAssembly);
			}
			
			// ----------------------------------------------------------
	
						
			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		

	}
	
	public void PefromDebitCardValidation(MbMessageAssembly VerRequestMsg, MbMessageAssembly outAssembly)throws MbException{
		// Connecting to the Card Management server .
		final String ZPK="027FAAD07C7AF55EE079C962607EE2FE";
		final int KEYSIZE=168;
		
			try {
				 String CardNUM = new String();
				 String Year = new String();
				 String Month = new String();
				 String Amount =new String();
				 String Currency = new String();
				
				 String AcquiringInstitution = new String();
					
				 MbMessage outMessage = new MbMessage();  	
				
				MbElement  InMSG = VerRequestMsg.getMessage().getRootElement();
				MbElement env = VerRequestMsg.getGlobalEnvironment().getRootElement();//headers
				MbElement yearMB = env.getFirstElementByPath("/var/cbms/year");
				MbElement monthMB = env.getFirstElementByPath("/var/cbms/month"); 
				CardNUM = InMSG.getFirstElementByPath("/XMLNSC/C24TRANREQ/CARD_NUMBER").getValueAsString();
				Year = (String)yearMB.getValueAsString();
				Month = (String)monthMB.getValueAsString();
				AcquiringInstitution = (String)getUserDefinedAttribute("ACQINST");
				
				
				ESocketWeb esocketweb = new ESocketWeb();
				esocketweb.initialize("/var/UBA/VeriCash/ubaaccountesocket.txt");

				esocketweb.connect();


				if (!esocketweb.isConnected())
				{
					System.out.println("Connecting to e-Socket Server Failed");
				}else {
					System.out.println("Connected to E-Socket Server Successfully");
				}

				//Linked Account Inquiry inquiry

				esocketweb.stopTracing();
				LinkedAccountsInquiry linkAcctEnqry = esocketweb.newLinkedAccountsInquiry();

				//identification info
				Identification identification = linkAcctEnqry.newIdentification();
				postilion.esocketweb.Card card = identification.newCard();
				card.setCardNumber(CardNUM);

				postilion.esocketweb.DateTime expiryDate = card.newExpiryDate();
				expiryDate.setYear(Year);
				expiryDate.setMonth(Month);

				try {

					//PINEncrypter ftm = new PINEncrypter();

					//card.setPinData(PinBlockEncryptionUtil.encryptPinBlock(CardNUM, "1111", UBALinkedAccountInquiry.ZPK, UBALinkedAccountInquiry.KEYSIZE));

				} catch (Exception e) {

					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				Routing routing = linkAcctEnqry.newRouting();
				routing.setAcquiringInstitution(AcquiringInstitution);


				LinkedAccountsInquiry linkAcctEnqryResp;

				try {
					String resp = "";
					String status = "";
					linkAcctEnqryResp = (LinkedAccountsInquiry ) esocketweb.send(linkAcctEnqry);
					outAssembly = new MbMessageAssembly(VerRequestMsg, outMessage);
					// copy headers from the input message
					MbMessage inMessage = VerRequestMsg.getMessage();
					copyMessageHeaders(inMessage, outMessage);
					if (linkAcctEnqryResp.getResponse().getResponseCode().equals("00"))
					{
						System.out.println("Linked Account Inquiry was successful");
						 resp = "000";
						 status = "SUCCESS";
						   MbElement outParser = outMessage.getRootElement().createElementAsLastChild(MbXMLNSC.PARSER_NAME); 
							MbElement outBody = outParser.createElementAsFirstChild(MbXMLNSC.FOLDER, "MSG", null);
							MbElement outBodyList = outBody.createElementAsLastChild(MbXMLNSC.FOLDER, "C24TRANRES", null);
							outBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "RESPCODE", resp); 
							outBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "STATUS", status);
							
							
						java.util.Hashtable linkAcctList = linkAcctEnqryResp.getLinkedAccountsList().getFields();

						Object [] ls = linkAcctList.values().toArray();

						int x=1;
						//for (LinkedAccount linkedAcct : ls)
						String [] acctType = new String[ls.length];
						String [] acctId = new String[ls.length];
						String [] acctCurrency = new String[ls.length];

						for (int k=0; k<ls.length; k++)
						{
							postilion.esocketweb.Account acct = ((postilion.esocketweb.LinkedAccount)ls[k]).getAccount();
							acctType[k] = acct.getType();
							acctId[k] = acct.getId();
							acctCurrency [k] = acct.getCurrency();

							System.out.println("Acct Type = " + acctType[k] + " Acct Id = " + acctId[k] + " Acct Currency = " + acctCurrency [k]);
							//System.out.println(" Sending Transfer Instruction ... ");
						
						
						//building the Response 
							MbElement inBodyList = outBodyList.createElementAsLastChild(MbXMLNSC.FOLDER, "ACCOUNTS", null);
							inBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "ACCOUNTID", acctId[k]);
							inBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "ACCOUNTTYPE", acctType[k] );
							inBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "ACCOUNTCCY", acctCurrency [k]);
						
						
						}
						getOutputTerminal("out").propagate(outAssembly);
					}else {
						resp =linkAcctEnqryResp.getResponse().getResponseCode();
						 status = "FAILURE";
						MbElement outParser = outMessage.getRootElement().createElementAsLastChild(MbXMLNSC.PARSER_NAME); 
						MbElement outBody = outParser.createElementAsFirstChild(MbXMLNSC.FOLDER, "MSG", null);
						MbElement outBodyList = outBody.createElementAsLastChild(MbXMLNSC.FOLDER, "C24TRANRES", null);
						outBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "RESPCODE", resp);
						outBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "STATUS", status);
						getOutputTerminal("out").propagate(outAssembly);
					}
				//	
				} catch (RuntimeException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}


			} catch (Exception exp) {
				 //exp.printStackTrace();
				 throw new MbUserException(this, "evaluate()", "", "", exp.toString(),null);
			}


		
}

	
	public String PerformVeriCashOperations(MbMessageAssembly VerRequestMsg, MbMessageAssembly outAssembly) throws MbException
	{
		String returnValue= new String();  	PostChannel channel = null;
		String txnAmount = new String(); 
		String decPointStr = new String(); 
		String txnAmtStr = new String();
		String txnDate = new String();
		String valueDate = new String();
		String debitCurrency = new String();
		String isoFLD24 = new String();
		String txnCurrency = new String();
		 String isoMTI = new String();
		String bankID = new String();
		String solID = new String();
		String fld102solID = new String();
		String fld102bankid = new String();
		String fld102drAcctNO = new String();
		String fld103crAcctNO = new String();
		String completeFld102 = new String();
		String completeFld103 = new String();
		
		String drAcctNO = new String();
		String crAcctNO = new String();
		String uid = new String();
		String uidate = new String();
		String cmsTransID = "" ;
		String applcode = null, interfacecode = null, serviceId = null;
		String stopCheque62= "";
		String errReason = "";
		String Actioncode ="";
		String stan ="";
		String f48 ="";
		String f125 = "";
		String status ="";
		String f56 = "";
		String f62 ="";
		int f48len =0;
		int f125len =0;
		String isoFLD125 = new String();
		String terminalloc = new String();
		int terminalloclen = 0;
				
		Date d = new Date();
	
	
//		boolean finacleFlag = true;
//		int finacleCount = 0;
		int uidLength;
		//Accessing UDP values
		MbElement env = VerRequestMsg.getGlobalEnvironment().getRootElement();
		MbElement inpprcncodeMB = env.getFirstElementByPath("/Variables/ProcessingCode");
		String inpprcncode = (String)inpprcncodeMB.getValueAsString();
		 if (inpprcncode.equalsIgnoreCase("51"))
		 {
		 isoMTI = "1420";
	}
		 else
		 {
			  isoMTI = (String)getUserDefinedAttribute("ISOMTI");
		 }
		String isoFLD3 = (String)getUserDefinedAttribute("ISOFLD3");
		if (inpprcncode.equalsIgnoreCase("51"))
		 { 
		 isoFLD24 = "400";
		 }
		else
		{
			 isoFLD24 = (String)getUserDefinedAttribute("ISOFLD24");	
		}
		String isoFLD32 = (String)getUserDefinedAttribute("ISOFLD32");
		String isoFLD123 = (String)getUserDefinedAttribute("ISOFLD123");
		String isoFLD124= (String)getUserDefinedAttribute("ISOFLD124");
		
		
		//String COLDFTDrAccNo = (String)getUserDefinedAttribute("COLDFTACCNO");
		BigDecimal txnAmt =null;
		
		MbMessage outMessage = new MbMessage();  
		try {
			
	
			MbElement inputRoot = VerRequestMsg.getMessage().getRootElement();
		//	ISOFinaclePackager finaclePackager= new ISOFinaclePackager();
			ISOPackager finaclePackager= new ISOFinacleBWYPackager();
			ISOMsg m = new ISOMsg();
			m.setPackager (finaclePackager);
			m.setMTI(isoMTI); 
			//headers
			MbElement hostNameMB = env.getFirstElementByPath("/Variables/tcpHostname");
			String hostName = (String)hostNameMB.getValueAsString();
			MbElement tcpPortMB = env.getFirstElementByPath("/Variables/tcpPort");
			String tcpPortStr = tcpPortMB.getValueAsString();
			Integer i = Integer.parseInt(tcpPortStr);
			int tcpport =(int)i;
			
			 if (inpprcncode.equalsIgnoreCase("100"))
			  {
				 
				 String chqstrtno = getValueByValidate(inputRoot, "/XMLNSC/CCPRequest/ChequeNo");
				 int chqstrtnoLength;
					//If amount length is less than 16 pad with 0
				 chqstrtnoLength = chqstrtno.length();
					if((chqstrtnoLength > 0 )&&(chqstrtnoLength<8)){
						chqstrtnoLength = 8-chqstrtnoLength;
						while(chqstrtnoLength>0){
							chqstrtno = "0".concat(chqstrtno);
							chqstrtnoLength = chqstrtnoLength-1;
						}//End While
					} 
				 
				 
			  
			  f62 = chqstrtno + "001";
			  txnCurrency = getValueByValidate(inputRoot,"/XMLNSC/CCPRequest/TRAN_CRNCY_CODE");
				debitCurrency = txnCurrency;
			
			  }
			
			
			
			
			
			
			 if (inpprcncode.equalsIgnoreCase("95"))
			  {
				// String f46 = getValueByValidate(inputRoot, "/XMLNSC/C24TRANREQ/fees");
				 
				 String chqstrtno = getValueByValidate(inputRoot, "/XMLNSC/C24TRANREQ/CHEQUE_REFERENCE_NUMBER");
				 int chqstrtnoLength;
					//If amount length is less than 16 pad with 0
				 chqstrtnoLength = chqstrtno.length();
					if((chqstrtnoLength > 0 )&&(chqstrtnoLength<8)){
						chqstrtnoLength = 8-chqstrtnoLength;
						while(chqstrtnoLength>0){
							chqstrtno = "0".concat(chqstrtno);
							chqstrtnoLength = chqstrtnoLength-1;
						}//End While
					}
				 
				 
				/* String noofleave = getValueByValidate(inputRoot, "/XMLNSC/C24TRANREQ/no_of_leaves");
				 
				 
				 int noofleaveLength;
					//If amount length is less than 16 pad with 0
				 noofleaveLength = noofleave.length();
					if((noofleaveLength > 0 )&&(noofleaveLength<3)){
						noofleaveLength = 3-noofleaveLength;
						while(chqstrtnoLength>0){
							noofleave = "0".concat(chqstrtno);
							noofleaveLength = noofleaveLength-1;
						}//End While
					} */
				 
				 String stopReason = "   ".concat((String)getUserDefinedAttribute("STOPREASON"));
 				  f62 = chqstrtno + "001" + stopReason;
 				 txnCurrency = getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/TRAN_CRNCY_CODE");
 				debitCurrency = txnCurrency;
 				  
 				  
			  }
			 if (inpprcncode.equalsIgnoreCase("51")) 
			 {
				 String  Origstan = getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/ORIGINAL_STAN");
				 
				 int OrigstanLength;
					//If stan length is less than 12 pad with 0
				 OrigstanLength = Origstan.length();
					if((OrigstanLength > 0 )&&(OrigstanLength<12)){
						OrigstanLength = 12-OrigstanLength;
						while(OrigstanLength>0){
							Origstan = "0".concat(Origstan);
							OrigstanLength = OrigstanLength-1;
						}//End While
					}
				 
				 
				 
				 
				 
				 
				 
				 String Origdtetime = getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/ORIGINAL_DATE_TIME");
				 /*	 int OrigdtetimeLength;
					//If amount length is less than 16 pad with 0
				 OrigdtetimeLength = Origstan.length();
					if((OrigdtetimeLength > 0 )&&(OrigdtetimeLength<14)){
						OrigdtetimeLength = 14-OrigdtetimeLength;
						while(OrigdtetimeLength>0){
							Origdtetime = "0".concat(Origdtetime);
							OrigdtetimeLength = OrigdtetimeLength-1;
						}//End While
					}*/
				 
				 
				 
				 
				 
				 String AcqInst = getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/ORIG_INST_CODE");
				 
				 int AcqInstLength;
					//If amount length is less than 16 pad with 0
				 AcqInstLength = AcqInst.length();
					if((AcqInstLength > 0 )&&(AcqInstLength<11)){
						AcqInstLength = 11-AcqInstLength;
						while(AcqInstLength>0){
							AcqInst = "0".concat(AcqInst);
							AcqInstLength = AcqInstLength-1;
						}//End While
					}
				 
				 
				 
			     f56  =  "1200"+ Origstan + Origdtetime + "11" + AcqInst; 
			 }
			 
			 
			 if (inpprcncode.equalsIgnoreCase("70") || inpprcncode.equalsIgnoreCase("50") || inpprcncode.equalsIgnoreCase("51") )
			  {
          txnAmount = getValueByValidate(inputRoot, "/XMLNSC/C24TRANREQ/TRAN_AMT");
			
			decPointStr = env.getFirstElementByPath("/Variables/Txn/decPoint").getValueAsString();
			int decPoint = Integer.parseInt(decPointStr.substring(0, 1));
			txnAmt = new BigDecimal(txnAmount);
			double base =10;
			double exponent=decPoint;
			//Removing decimal point
			txnAmt = txnAmt.multiply(new BigDecimal(Math.pow(base, exponent)));
			txnAmt = txnAmt.setScale(0, RoundingMode.FLOOR);
			//Throw exception if length is greater than 16
			if (txnAmt.toString().length()>16) {
				throw  new MbUserException(this, "evaluate()", "", "", "ESB internal Exception Txn Amt is Exceeded limit",null);
			}
			String amount = txnAmt.toString();
			int amountLength;
			//If amount length is less than 16 pad with 0
			amountLength = amount.length();
			if((amountLength > 0 )&&(amountLength<16)){
				amountLength = 16-amountLength;
				while(amountLength>0){
					amount = "0".concat(amount);
					amountLength = amountLength-1;
				}//End While
			}//End IF
			txnAmtStr =amount;
		}
		    uidate = new SimpleDateFormat("mmss").format(d);
			SecureRandom prng = SecureRandom.getInstance("SHA1PRNG");
		    uid = new Integer(prng.nextInt()).toString();
		    //Generate unique id
		    if(uid.length() >= 8){
		    	uid = uid.substring(uid.length()-8, uid.length());
		    }
		    else {
		    	uidLength = 8 - uid.length();
		    	while(uidLength > 0){
		    		uid = uid.concat("1");
		    		uidLength = uidLength - 1;
		    	}//End while uidLength
		    }//End else
		    uid = uidate + uid;
		    uid = uid.replace("-", "1");
		    
		   
		    txnDate = env.getFirstElementByPath("/Variables/CurrDte").getValueAsString();
		
			txnDate = txnDate.replace("-", "");
			txnDate = txnDate.replace(":", "");
			txnDate = txnDate.replace("T", "");
			//txnDate = txnDate.concat("000000");
			//valueDate = inputRoot.getFirstElementByPath("/XMLNSC/MSGDETAIL/VALUEDATE").getValueAsString();
			valueDate =  env.getFirstElementByPath("/Variables/ValDte").getValueAsString();
			
			valueDate = valueDate.replace("-", ""); 
			valueDate = valueDate.replace(":", ""); 
			valueDate = valueDate.replace("T", ""); 
			 
			
			
			//txnCurrency = getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/TXNCCY");
			//txnCurrency = getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/TRAN_CRNCY_CODE");

			bankID = env.getFirstElementByPath("/Variables/Iso/bankID").getValueAsString();
			fld102bankid = String.format("%1$" + (-11) + "s", bankID);
			solID = env.getFirstElementByPath("/Variables/Iso/solID").getValueAsString();
			fld102solID = String.format("%1$" + (-8) + "s", solID);
			
			
			if (inpprcncode.equalsIgnoreCase("100"))
			  {
			drAcctNO = getValueByValidate(inputRoot,"/XMLNSC/CCPRequest/CustomerAccountNumber");
			  }
			else
			{
				drAcctNO = getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/DR_ACCT_NUM");	
			}
			fld102drAcctNO = String.format("%1$" + (-19) + "s", drAcctNO);
			completeFld102 = fld102bankid + fld102solID + fld102drAcctNO;
			
			  if (inpprcncode.equalsIgnoreCase("70"))
			  {
			crAcctNO = getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/CR_ACCT_NUM");
			fld103crAcctNO = String.format("%1$" + (-19) + "s",crAcctNO);
			completeFld103 = fld102bankid + fld102solID + fld103crAcctNO;
			  }
			  if (inpprcncode.equalsIgnoreCase("51"))
			  {
				  String spce = "  ";
			crAcctNO = getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/CR_ACCT_NUM");
			fld103crAcctNO = String.format("%1$" + (-19) + "s",crAcctNO);
			completeFld103 = spce +fld102bankid + fld102solID + fld103crAcctNO;
			 txnCurrency = getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/TRAN_CRNCY_CODE");
				debitCurrency = txnCurrency;
			  }
			  if (inpprcncode.equalsIgnoreCase("50")  )
			  {
			crAcctNO = getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/CR_ACCT_NUM");
			String spce = "  ";
			fld103crAcctNO = String.format("%1$" + (-19) + "s",crAcctNO);
			completeFld103 = spce + fld102bankid + fld102solID + fld103crAcctNO;
			txnCurrency = getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/TRAN_CRNCY_CODE");
			debitCurrency = txnCurrency;
			isoFLD125 = getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/RESERVE_FLD_1");
			terminalloc =inputRoot.getFirstElementByPath("/XMLNSC/C24TRANREQ/TERMINAL_NAME_LOC").getValueAsString();
			
			if (terminalloc == null)
			
				
			{
				terminalloc = " " ;	
			}	
				else
				{
				terminalloc = getValueByValidate(inputRoot,"/XMLNSC/C24TRANREQ/TERMINAL_NAME_LOC"); 
				
			   }
			
			  }
			
			 if (inpprcncode.equalsIgnoreCase("31"))
			 {
			isoFLD3 = "310000";
			 }
			 if (inpprcncode.equalsIgnoreCase("100"))
			 {
			isoFLD3 = "940000";
			 }
			 if (inpprcncode.equalsIgnoreCase("95"))
			 {
			isoFLD3 = "950000";
			 }
			if (inpprcncode.equalsIgnoreCase("38"))
			{
			isoFLD3 = "380000";
			}
			if (inpprcncode.equalsIgnoreCase("82"))
			{
			isoFLD3 = "820000";
			}  
			
			
			m.set(new ISOField(2, "VERICASH"));	
			m.set(new ISOField(3, isoFLD3));
			if (inpprcncode.equalsIgnoreCase("70") || inpprcncode.equalsIgnoreCase("50") || inpprcncode.equalsIgnoreCase("51"))
			{
			if (txnAmtStr != null) {
			m.set(new ISOField(4,txnAmtStr)); 
			}
			} else
			{
				m.set(new ISOField(4,"0000000000000000"));
			}
			m.set(new ISOField(11,uid)); 
			if (txnDate != null) {
			m.set(new ISOField(12, txnDate)); } 
			if (valueDate != null) {
			m.set(new ISOField(17, valueDate)); }
			m.set(new ISOField(24, isoFLD24));
			m.set(new ISOField(32, isoFLD32));
			
			if (inpprcncode.equalsIgnoreCase("50"))
			{
				m.set(new ISOField(43, terminalloc));	
			}
			
			  if (inpprcncode.equalsIgnoreCase("70") || inpprcncode.equalsIgnoreCase("50") || inpprcncode.equalsIgnoreCase("100") || inpprcncode.equalsIgnoreCase("51")|| inpprcncode.equalsIgnoreCase("95"))
			  {
			if (debitCurrency != null) {
			m.set(new ISOField(49, debitCurrency)); 
			}
			
		   if (txnCurrency != null) {
		   m.set(new ISOField(50, txnCurrency)); }
			  }
			  if (inpprcncode.equalsIgnoreCase("51")){ 
				  if (f56 != null) {
					   m.set(new ISOField(56, f56)); }
						  }
			  
			  if (inpprcncode.equalsIgnoreCase("95") ||  inpprcncode.equalsIgnoreCase("100"))
			  {
			if (f62 != null) {
			m.set(new ISOField(62, f62)); }
			
			  }  
			if (completeFld102 != null) {
			m.set(new ISOField(102, completeFld102)); }
			
			if (inpprcncode.equalsIgnoreCase("50") ||  inpprcncode.equalsIgnoreCase("51") )
			  {
				if (completeFld103 != null) {
			m.set(new ISOField(103, completeFld103));
		//	if (completeFld103 != null) {
				}
			  }
			m.set(new ISOField(123, isoFLD123));
			m.set(new ISOField(124, isoFLD124));
			if (inpprcncode.equalsIgnoreCase("50"))
			  {
			m.set(new ISOField(125, isoFLD125));
			  }
			
			 
			
			channel = new PostChannel(hostName, tcpport, finaclePackager);
			MbElement envFinRetry = env.createElementAsLastChild(MbXMLNSC.FOLDER, "FinacleRetry", null);
			ISOMsg resp = finacleConnect(channel, m, envFinRetry);
			errReason = resp.getString(127);
			Actioncode =resp.getString(39);
			
			if (Actioncode.equalsIgnoreCase("000"))
			{
				status = "SUCCESS";
				/*f48 = resp.getString(48);
				// f48len = f48.length();
				f125 =resp.getString(125);
				//f125len = f125.length();
*/			} else
			{
				status = "FAILED";
			}
			stan = resp.getString(11);
			f48 = resp.getString(48);
			//int f48len = f48.length();
			f125 =resp.getString(125);
		//	int f125len = f125.length();
			MbMessage inMessage = VerRequestMsg.getMessage();
			outAssembly = new MbMessageAssembly(VerRequestMsg, outMessage);
			// copy headers from the input message
			copyMessageHeaders(inMessage, outMessage);
			//Create the XMLNSC Parser element
		    MbElement outParser = outMessage.getRootElement().createElementAsLastChild(MbXMLNSC.PARSER_NAME); 
			MbElement outBody = outParser.createElementAsFirstChild(MbXMLNSC.FOLDER, "MSG", null);
			
			MbElement outBodyList = outBody.createElementAsLastChild(MbXMLNSC.FOLDER, "C24TRANRES", null);
			outBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "ACTION_CODE", Actioncode);
			outBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "STAN", stan);
			outBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "TRAN_DATE_TIME", resp.getString(12));			
			outBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "FIELD48", f48);
			//outBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "F48LEN", f48len);
			outBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "FIELD125", f125);
			//outBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "F125LEN", f125len);
			outBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "STATUS", status);
			outBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "ERRCODE",Actioncode);
			
			//Propagate the message to out terminal
			getOutputTerminal("out").propagate(outAssembly);
			  	
		}//End try block
		//Handling time out exception
		catch (SocketTimeoutException  timeoutExc) {
			//Accessing environment variable
		//	MbElement env = VerRequestMsg.getGlobalEnvironment().getRootElement();
			//Make a new mb message based on the input message
			MbMessage inMessage = VerRequestMsg.getMessage();
			outAssembly = new MbMessageAssembly(VerRequestMsg, outMessage);
			// copy headers from the input message
			
			copyMessageHeaders(inMessage, outMessage); 
			returnValue = "99";
			//Create the XMLNSC Parser element
		    MbElement outParser = outMessage.getRootElement().createElementAsLastChild(MbXMLNSC.PARSER_NAME); 
			MbElement outBody = outParser.createElementAsFirstChild(MbXMLNSC.FOLDER, "MSG", null);
			
			
			MbElement outBodyList = outBody.createElementAsLastChild(MbXMLNSC.FOLDER, "C24TRANRES", null);
			
			outBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "STATUS", returnValue);
			outBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "ACTION_CODE", returnValue );
			outBodyList.createElementAsLastChild(MbXMLNSC.FIELD, "ERRREASON", errReason );
			//Propagating message to alternate terminal
			getOutputTerminal("alternate").propagate(VerRequestMsg);
		}//End catch socket time out exception
		catch(MbException e){
			throw e;
		} 
		catch (Exception exp) {
			throw new MbUserException(this, "evaluate()", "", "", exp.toString(),null);
		}
		//Disconnecting finacle system connection
		finally{
			try {
				if(channel != null){ 
					channel.disconnect();}
				if(outMessage != null){
					outMessage.clearMessage();}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}//End finally disconnecting finacle connection
		return returnValue;
	}//End do fund transfer method
	
	// copy headers from the input message
	 public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage) throws MbException
	 {
	    MbElement outRoot = outMessage.getRootElement();
	    //iterate though the headers starting with the first child of the root element
	    MbElement header = inMessage.getRootElement().getFirstChild();
	    // stop before the last child
	    while((header != null) && (header.getNextSibling() != null)){
	        outRoot.addAsLastChild(header.copy());
	        header = header.getNextSibling();
	    }//End while
	 }//End copy message headers
	 
	 public ISOMsg finacleConnect(PostChannel channel, ISOMsg m, MbElement envFinRetry)throws ISOException, IOException, InterruptedException, MbException
	 {
		 int finacleCount =0;
			String returnValue = null;
			
		 ISOMsg resp = null;
			while (true) {
				/**
				 * For Negitive Response hit the finacle server 
				 * upto 3 times only.*
				 */
				int noofretrials  = (int) getUserDefinedAttribute("NOOFRETRIALS"); 
				if(finacleCount< noofretrials){
					channel.connect();
					channel.setTimeout(1000*60*1);  
					channel.send(m);
					//Receiving response from Finacle
					resp = channel.receive();
					if(resp == null){
						throw  new MbUserException(this, "evaluate()", "", "", "FIN RESP NULL",null);
					}
					returnValue = resp.getString(39);
					finacleCount = finacleCount +1;
				}
				else
					break;
				
				if((	returnValue.equalsIgnoreCase("904") || 
						returnValue.equalsIgnoreCase("906") || 
						returnValue.equalsIgnoreCase("911") || 
						returnValue.equalsIgnoreCase("907") || 
						returnValue.equalsIgnoreCase("909")) 
				    	 && finacleCount >=noofretrials){
					break;
				}
				if(		!returnValue.equalsIgnoreCase("904") && 
						!returnValue.equalsIgnoreCase("906") && 
						!returnValue.equalsIgnoreCase("911") && 
						!returnValue.equalsIgnoreCase("907") &&
						!returnValue.equalsIgnoreCase("909"))
					   break;
				Thread.sleep(30*1000);
				MbElement iterationObj = envFinRetry.createElementAsLastChild(MbXMLNSC.FOLDER, "Iteration", null);
				iterationObj.createElementAsLastChild(MbXMLNSC.FIELD, "returnValue", returnValue);
				iterationObj.createElementAsLastChild(MbXMLNSC.FIELD, "ReturnCount", Integer.toString(finacleCount));
				
			}//End While
			
			return resp;
			
		}
	 public String getValueByValidate(MbElement parentEle,String path) throws MbException
		{
			MbElement eleObj = null;
			String elementInStrg = null;
			
				eleObj=parentEle.getFirstElementByPath(path);
				if(eleObj!=null){
				   elementInStrg = eleObj.getValueAsString();
				   if(elementInStrg == null)
				    throw new MbUserException(this, "getElementByPath()", "", "", path +" NULL",null);
				  }else
				   throw new MbUserException(this, "getElementByPath()", "", "", path +" NULL",null);
			
			return elementInStrg;
		}

//Validate Debt Card Expiry Date.
	 
public static String  doTransfer(MbMessageAssembly VerRequestMsg,String[] acctId,String[] acctType,ESocketWeb esocketweb) throws MbException{
	try{
		String Rescode = new String();
		 String CardNUM = new String();
		 String Year = new String();
		 String Month = new String();
		 String Amount =new String();
		 String Currency = new String();
		 String AcquiringInstitution = new String();
		 
		MbElement  InMSG = VerRequestMsg.getMessage().getRootElement();
		CardNUM = InMSG.getFirstElementByPath("/XMLNSC/C24TRANREQ/CARDNUMBER").toString();
		Year = InMSG.getFirstElementByPath("/XMLNSC/C24TRANREQ/YEAR").toString();
		Month = InMSG.getFirstElementByPath("/XMLNSC/C24TRANREQ/MONTH").toString();
	//	Amount = InMSG.getFirstElementByPath("/XMLNSC/C24TRANREQ/AMOUNT").toString();
	//	Currency = InMSG.getFirstElementByPath("/XMLNSC/C24TRANREQ/CURRENCY").toString();
		AcquiringInstitution = InMSG.getFirstElementByPath("/XMLNSC/C24TRANREQ/ACQUIRINGINSTITUTION").toString();
		
	
			
	AccountsTransfer transfer = esocketweb.newAccountsTransfer();
	
	//identification info

	
	Identification identification = transfer.newIdentification();
	postilion.esocketweb.Card card = identification.newCard();
	card.setCardNumber(CardNUM);

	postilion.esocketweb.DateTime expiryDate = card.newExpiryDate();
	expiryDate.setYear(Year);
	expiryDate.setMonth(Month);
    System.out.println("22222222222");
	//financial info
	Financial financial = transfer.newFinancial();
	Amount amount = financial.newTransactionAmount();
	amount.setAmount(Amount);
	amount.setCurrency(Currency);
	financial.setTransactionAmount(amount);

	postilion.esocketweb.Account fromAccount = transfer.newFromAccount();
	fromAccount.setType(acctType[0]);
	fromAccount.setId(acctId[0]);
	fromAccount.setCurrency(Currency);

	postilion.esocketweb.Account toAccount = transfer.newToAccount();
	toAccount.setType(acctType[1]);
	toAccount.setId(acctId[1]);
	toAccount.setCurrency(Currency);
    System.out.println("33333333333");
	//Routing Info
	Routing routing = transfer.newRouting();
	routing.setAcquiringInstitution(AcquiringInstitution);
    System.out.println("444444444444");
	AccountsTransfer transferResponse  =  (AccountsTransfer) esocketweb.send(transfer);
    System.out.println("555555555555555");
    
   
    Rescode = transferResponse.getResponse().getResponseCode();
	if (transferResponse.getResponse().getResponseCode().equals("00"))
	{
		System.out.println("Account Transfer Was Successful ...");
		
		
	} else {
		System.out.println("Account Transfer FAILED!  ...");
		
	}

	}catch (Exception e) {
		//Handle Exception Here.
	}
		
		return Rescode;

}
			
}//End gcp finacle java compute class



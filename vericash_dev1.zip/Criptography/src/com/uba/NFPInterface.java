package com.uba;

import nfp.ssm.core.SSMLib;

public class NFPInterface
{
  public static String encryptNIBSSMsg(String inputStr, String NIBSS_PUBLIC_KEY, String UBA_PUBLIC_KEY, String UBA_PRIVATE_KEY, String XPASS)
  {
    SSMLib sSMLib = new SSMLib(NIBSS_PUBLIC_KEY, UBA_PRIVATE_KEY);
    String resultStr = null;
    try
    {
      if ((inputStr != null) && (!"".equals(inputStr))) {
        resultStr = sSMLib.encryptMessage(inputStr);
      }
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
    finally
    {
      sSMLib = null;
    }
    return resultStr;
  }
  
  public static String decryptNIBSSMsg(String input, String NIBSS_PUBLIC_KEY, String UBA_PUBLIC_KEY, String UBA_PRIVATE_KEY, String XPASS)
  {
    SSMLib sSMLib = new SSMLib(NIBSS_PUBLIC_KEY, UBA_PRIVATE_KEY);
    String resultStr = null;
    try
    {
      if ((input != null) && (!"".equals(input))) {
        resultStr = sSMLib.decryptFile(input, XPASS);
      }
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
    finally
    {
      sSMLib = null;
    }
    return resultStr;
  }
}
